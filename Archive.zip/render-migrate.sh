#!/usr/bin/env bash
npx prisma generate
npx prisma migrate deploy