## Extension Configuration

When configuring your Admin Link extensions, you can specify various targeting options. Below are the valid extension targets you can use to define where your link will appear within the Shopify Admin.

### Valid Extension Targets

- **Abandoned Checkout Details Page**
  - `admin.abandoned-checkout-details.action.link`

- **Collection Index and Detail Pages**
  - `admin.collection-index.action.link`
  - `admin.collection-details.action.link`

- **Customer Index and Detail Pages**
  - `admin.customer-index.action.link`
  - `admin.customer-details.action.link`
  - `admin.customer-index.selection-action.link`

- **Discount Index and Detail Pages**
  - `admin.discount-index.action.link`
  - `admin.discount-details.action.link`

- **Draft Order Index and Detail Pages**
  - `admin.draft-order-index.action.link`
  - `admin.draft-order-details.action.link`
  - `admin.draft-order-index.selection-action.link`

- **Order Index, Detail Pages, and Order Fulfilled Card**
  - `admin.order-index.action.link`
  - `admin.order-details.action.link`
  - `admin.order-index.selection-action.link`
  - `admin.order.fulfilled-card.link`

- **Product Index and Detail Pages**
  - `admin.product-index.action.link`
  - `admin.product-details.action.link`
  - `admin.product-index.selection-action.link`

- **Product Variant Detail Pages**
  - `admin.product-variant-details.action.link`

- **Get Support Button**
  -`admin.app.support.link`
